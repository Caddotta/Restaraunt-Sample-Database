CREATE TABLE employee_dim (
    employeekey       INTEGER NOT NULL,
    employeename      VARCHAR2(30 CHAR),
    employeewage      NUMBER,
    employeephone     VARCHAR2(10 CHAR),
    employeeaddress   VARCHAR2(50 CHAR),
    beffdate          DATE,
    eeffdate          DATE,
    currentflag       CHAR(1)
);

ALTER TABLE employee_dim ADD CONSTRAINT employee_dim_pk PRIMARY KEY ( employeekey );

CREATE TABLE expense_dim (
    expensekey                   INTEGER NOT NULL,
    expsensetypeflag             CHAR(1 CHAR) NOT NULL,
    wage_expensedim_wage_key     INTEGER,
    order_expensedim_order_key   INTEGER,
    beffdate                     DATE,
    eeffdate                     DATE,
    currentflag                  CHAR(1)
);

ALTER TABLE expense_dim ADD CONSTRAINT expense_dim_pk PRIMARY KEY ( expensekey );

CREATE TABLE fact_cost (
    employee_dim_employeekey   INTEGER NOT NULL,
    time_dim_timekey           INTEGER NOT NULL,
    expense_dim_expensekey     INTEGER NOT NULL,
    costamountfact             NUMBER NOT NULL
);

ALTER TABLE fact_cost
    ADD CONSTRAINT fact_cost_pk PRIMARY KEY ( expense_dim_expensekey,
                                              time_dim_timekey,
                                              employee_dim_employeekey );

CREATE TABLE fact_sales (
    menu_item__key_menuitemkey   INTEGER NOT NULL,
    party_dim_partykey           INTEGER NOT NULL,
    employee_dim_employeekey     INTEGER NOT NULL,
    time_dim_timekey             INTEGER NOT NULL,
    saleamountfact               NUMBER NOT NULL
);

ALTER TABLE fact_sales
    ADD CONSTRAINT fact_sales_pk PRIMARY KEY ( menu_item__key_menuitemkey,
                                               time_dim_timekey,
                                               party_dim_partykey,
                                               employee_dim_employeekey );

CREATE TABLE menu_item_dim (
    menuitemkey    INTEGER NOT NULL,
    menuitemtype   VARCHAR2(15),
    menuitemname   VARCHAR2(30),
    beffdate       DATE,
    eeffdate       DATE,
    currentflag    CHAR(1)
);

ALTER TABLE menu_item_dim ADD CONSTRAINT menu_item__key_pk PRIMARY KEY ( menuitemkey );

CREATE TABLE order_expense (
    order_key       INTEGER NOT NULL,
    order_desc      VARCHAR2(20),
    supplier        VARCHAR2(15 CHAR),
    supplierphone   VARCHAR2(10 CHAR)
);

ALTER TABLE order_expense ADD CONSTRAINT order_expensedim_pk PRIMARY KEY ( order_key );

CREATE TABLE party_dim (
    partykey           INTEGER NOT NULL,
    partyname          VARCHAR2(50 CHAR),
    partysize          INTEGER,
    partyarrivaldate   DATE,
    currentflag        CHAR(1),
    beffdate           DATE,
    eeffdate           DATE
);

ALTER TABLE party_dim ADD CONSTRAINT party_dim_pk PRIMARY KEY ( partykey );

CREATE TABLE time_dim (
    timekey                INTEGER NOT NULL,
    day                    NUMBER(2) NOT NULL,
    month                  NUMBER(2) NOT NULL,
    year                   NUMBER(4),
    hourminute             DATE,
    weekday_flag           CHAR(1),
    quater_finalday_flag   CHAR(1)
);

ALTER TABLE time_dim ADD CONSTRAINT time_dim_pk PRIMARY KEY ( timekey );

CREATE TABLE wage_expense (
    wage_key      INTEGER NOT NULL,
    hoursworked   NUMBER(2, 2),
    beffdate1     DATE,
    eeffdate      DATE,
    currentflag   CHAR(1)
);

ALTER TABLE wage_expense ADD CONSTRAINT wage_expensedim_pk PRIMARY KEY ( wage_key );

--  ERROR: FK name length exceeds maximum allowed length(30) 

ALTER TABLE expense_dim
    ADD CONSTRAINT expense_dim_order_im_fk FOREIGN KEY ( order_expensedim_order_key )
        REFERENCES order_expense ( order_key );

ALTER TABLE expense_dim
    ADD CONSTRAINT expense_dim_wage_expensedim_fk FOREIGN KEY ( wage_expensedim_wage_key )
        REFERENCES wage_expense ( wage_key );

ALTER TABLE fact_cost
    ADD CONSTRAINT fact_cost_employee_dim_fk FOREIGN KEY ( employee_dim_employeekey )
        REFERENCES employee_dim ( employeekey );

ALTER TABLE fact_cost
    ADD CONSTRAINT fact_cost_expense_dim_fk FOREIGN KEY ( expense_dim_expensekey )
        REFERENCES expense_dim ( expensekey );

ALTER TABLE fact_cost
    ADD CONSTRAINT fact_cost_time_dim_fk FOREIGN KEY ( time_dim_timekey )
        REFERENCES time_dim ( timekey );

ALTER TABLE fact_sales
    ADD CONSTRAINT fact_sales_employee_dim_fk FOREIGN KEY ( employee_dim_employeekey )
        REFERENCES employee_dim ( employeekey );

ALTER TABLE fact_sales
    ADD CONSTRAINT fact_sales_menu_item__key_fk FOREIGN KEY ( menu_item__key_menuitemkey )
        REFERENCES menu_item_dim ( menuitemkey );

ALTER TABLE fact_sales
    ADD CONSTRAINT fact_sales_party_dim_fk FOREIGN KEY ( party_dim_partykey )
        REFERENCES party_dim ( partykey );

ALTER TABLE fact_sales
    ADD CONSTRAINT fact_sales_time_dim_fk FOREIGN KEY ( time_dim_timekey )
        REFERENCES time_dim ( timekey );