	--Removes all content within database connection
--BEGIN
--  FOR TABLE_POINTER IN (
--  SELECT TABLE_NAME
--  FROM USER_TABLES ) LOOP
--    BEGIN
--      DBMS_OUTPUT.PUT_LINE(UTL_LMS.FORMAT_MESSAGE('Dropping table:%s', TABLE_POINTER.TABLE_NAME));
--      EXECUTE IMMEDIATE UTL_LMS.FORMAT_MESSAGE('DROP TABLE %s CASCADE CONSTRAINTS PURGE',TABLE_POINTER.TABLE_NAME);
--      EXCEPTION WHEN OTHERS THEN
--      DBMS_OUTPUT.PUT_LINE(UTL_LMS.FORMAT_MESSAGE('Could not drop table: %s Reason: %s', TABLE_POINTER.TABLE_NAME, SQLERRM));
--    END;
--  END LOOP;
--END;
--/

CREATE TABLE Employees(
    EmployeeID             INTEGER NOT NULL,
    EmployeeType           VARCHAR2(20 CHAR),
    EmployeeWage           NUMBER,
    EmployeeDOB            DATE,
    EmployeeAddress        VARCHAR2(100 CHAR),
    EmployeeSupervisor     INTEGER,
    HireDate               DATE,
    Supervisor             INTEGER NOT NULL,
    CONSTRAINT Employee_PK PRIMARY KEY (EmployeeID)
);
ALTER TABLE Employees ADD CONSTRAINT Supervisor_FK FOREIGN KEY (Supervisor) references Employees (EmployeeID);
CREATE INDEX Employees_EmployeeType_ix ON Employees (EmployeeType);
CREATE INDEX Employees_EmployeeWage_ix ON Employees (EmployeeWage);
CREATE INDEX Employees_EmployeeHD_ix ON Employees (HireDate);

CREATE TABLE Parties(
    PartyID                    INTEGER NOT NULL,
    PartyName                  VARCHAR2(50 CHAR) NOT NULL,
    PartyServer                INTEGER NOT NULL,
    PersonQty                  INTEGER NOT NULL,
    TableNo                    INTEGER NOT NULL,
    ArrivalTime                TIMESTAMP DEFAULT NULL,
    DepartureTime              TIMESTAMP DEFAULT NULL,
    
    CONSTRAINT PartyID_PK PRIMARY KEY (PartyID),
    CONSTRAINT PartyServer_FK FOREIGN KEY  (PartyServer) references Employees (EmployeeID)
);
CREATE INDEX Parties_PartyName_ix ON Parties (PartyName);
CREATE INDEX Parties_PartyServer_ix ON Parties (PartyServer);
CREATE INDEX Parties_PersonQTY_ix ON Parties (PersonQTY);
CREATE INDEX Parties_ArrivalTime_ix ON Parties (ArrivalTime);

CREATE TABLE Reservations(
    ReservationTime            TIMESTAMP NOT NULL,
    PartyID                    INTEGER NOT NULL,
    --PartyName                  VARCHAR2(50 CHAR) NOT NULL,
    ResAnsweredCall            INTEGER NOT NULL,
    --PersonQty                  INTEGER NOT NULL,
    --TableNo                    INTEGER NOT NULL,
    ReservationPhone           VARCHAR2(9 CHAR),
    ResAccommodations          VARCHAR2(100 CHAR)
);
ALTER TABLE Reservations ADD CONSTRAINT Reservation_PK PRIMARY KEY (ReservationTime, PartyID);
ALTER TABLE Reservations ADD CONSTRAINT ResPartyID_FK FOREIGN KEY (PartyID) references Parties (PartyID);
ALTER TABLE Reservations ADD CONSTRAINT ResAnsweredCall_FK FOREIGN KEY (ResAnsweredCall) references Employees (EmployeeID);

CREATE TABLE Party_Orders(
    OrderID           INTEGER NOT NULL,
    PartyID           INTEGER NOT NULL,
--    OrderCost         NUMBER NOT NULL, --Compiled from sum of P_Order_Details MenuItemPrice for all matching OrderID
    Tip               NUMBER DEFAULT 0,
    PayerName         VARCHAR2(20 CHAR),
    PaymentType       VARCHAR2(10 CHAR),
    
    CONSTRAINT OrderID_PK PRIMARY KEY (OrderID),
    CONSTRAINT PartyID_FK FOREIGN KEY (PartyID) references Parties (PartyID)
);
CREATE INDEX PartyO_PartyID_ix ON Party_Orders (PartyID);
--CREATE INDEX PartyO_OrderCost_ix ON Party_Orders (OrderCost);
CREATE INDEX PartyO_Tip_ix ON Party_Orders (Tip);
CREATE INDEX PartyO_PaymentType_ix ON Party_Orders (PaymentType);

CREATE TABLE Menu_Items(
    MenuItemID       INTEGER NOT NULL,
    MenuItemName     VARCHAR2(50 CHAR) NOT NULL,
    MenuItemPrice    NUMBER NOT NULL,
    MenuItemType     VARCHAR2(20),
    AddedDate        DATE,
    AvailableUntil   DATE,
    
    CONSTRAINT Menu_Item_PK PRIMARY KEY (MenuItemID)
);
CREATE INDEX MenuIt_MenuItemPrice_ix ON Menu_Items (MenuItemPrice);
CREATE INDEX MenuIt_MenuItemType_ix ON Menu_Items (MenuItemType);
CREATE INDEX MenuIt_AddedDate_ix ON Menu_Items (AddedDate);

CREATE TABLE P_Order_Details(
    MenuItemID                   INTEGER NOT NULL,
    OrderID                      INTEGER NOT NULL,
    EmployeeID                   INTEGER NOT NULL,
    --MenuItemPrice                NUMBER NOT NULL,
    Accommodations               VARCHAR2(100 CHAR)
);
ALTER TABLE P_Order_Details ADD CONSTRAINT POD_PK PRIMARY KEY (MenuItemID, OrderID);
ALTER TABLE P_Order_Details ADD CONSTRAINT POD_MenuItemID_FK FOREIGN KEY (MenuItemID) references Menu_Items (MenuItemID);
ALTER TABLE P_Order_Details ADD CONSTRAINT POD_OrderID_FK FOREIGN KEY (OrderID) references Party_Orders (OrderID);    
ALTER TABLE P_Order_Details ADD CONSTRAINT EmployeeID_FK FOREIGN KEY (EmployeeID) references Employees (EmployeeID);
CREATE INDEX PartyODet_EmployeeID_ix ON P_Order_Details (EmployeeID);

CREATE TABLE Suppliers(
    SupplierName      VARCHAR2(50 CHAR) NOT NULL,
    SupplierPhone     VARCHAR2(9 CHAR),
    SupplierAddress   VARCHAR2(50 CHAR),
    
    CONSTRAINT SupplierName_PK PRIMARY KEY (SupplierName)
);

CREATE TABLE Rst_Orders(
    SupplyOrderID            INTEGER NOT NULL,
    EmployeeID               INTEGER NOT NULL,
    DateOrdered              DATE,
    DateArrived              DATE NOT NULL,
    SupplierName             VARCHAR2(50) NOT NULL,
    SupplyOrderCost          NUMBER NOT NULL,
    
    CONSTRAINT RstOrder_PK PRIMARY KEY (SupplyOrderId),
    CONSTRAINT RstOrderEmployeeID_FK FOREIGN KEY (EmployeeID) references Employees (EmployeeID),
    CONSTRAINT RstOrderSupplierName_FK FOREIGN KEY (SupplierName) references Suppliers (SupplierName)
);
CREATE INDEX RstOrd_EmployeeID_ix ON Rst_Orders (EmployeeID);
CREATE INDEX RstOrd_DateOrdered_ix ON Rst_Orders (DateOrdered);
CREATE INDEX RstOrd_SupplyOrderCost_ix ON Rst_Orders (SupplyOrderCost);

CREATE TABLE Rst_Order_Details(
ItemID                  INTEGER NOT NULL,
SupplyOrderID           INTEGER NOT NULL,
ItemName                VARCHAR2(50 CHAR) NOT NULL,
ItemType                VARCHAR2(20 CHAR),
Designation             VARCHAR2(10 CHAR),

CONSTRAINT ItemID_PK PRIMARY KEY (ItemID),
CONSTRAINT SupplyOrderID_FK FOREIGN KEY (SupplyOrderID) references Rst_Orders (SupplyOrderID)
);
CREATE INDEX RstOD_ItemName_ix ON Rst_Order_Details (ItemName);
CREATE INDEX RstOD_ItemType_ix ON Rst_Order_Details (ItemType);

--subclass of Rst_Order_Details
CREATE TABLE Ingredients(
IngredientID            INTEGER NOT NULL,
ItemID                  INTEGER NOT NULL,

CONSTRAINT IngredientID_PK PRIMARY KEY (IngredientID),
CONSTRAINT ItemID_FK FOREIGN KEY (ItemID) references Rst_Order_Details (ItemID)
);
CREATE INDEX Ingred_ItemID_ix ON Ingredients (ItemID);

--Associative Entity of Menu_Items and Rst_Order_Details
CREATE TABLE Menu_Item_Details(
    MenuItemID     INTEGER NOT NULL,
    IngredientID   INTEGER NOT NULL, 
    
    CONSTRAINT MenuItemID_IngredientID_PK PRIMARY KEY (MenuItemID, IngredientID),
    CONSTRAINT MenuItemID_FK FOREIGN KEY (MenuItemID) references Menu_Items (MenuItemID),
    CONSTRAINT IngredientID_FK FOREIGN KEY (IngredientID) references Ingredients (IngredientID)
);

--subclass of employees
CREATE TABLE KitchenWorkers(
    EmployeeID INTEGER NOT NULL,
    KitchenStation VARCHAR2(10),
    
    CONSTRAINT KitchenWorker_PK PRIMARY KEY (EmployeeID),
    CONSTRAINT KitchenWorker_FK FOREIGN KEY (EmployeeID) references Employees (EmployeeID)
);
--subclass of employees
CREATE TABLE FrontWorkers(
    EmployeeID INTEGER NOT NULL,
    Front_Section VARCHAR2(10),
    
    CONSTRAINT FrontWorker_PK PRIMARY KEY (EmployeeID),
    CONSTRAINT FrontWorker_FK FOREIGN KEY (EmployeeID) references Employees (EmployeeID)
);